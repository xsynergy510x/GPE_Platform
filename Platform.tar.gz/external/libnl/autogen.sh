#!/bin/bash

autoreconf -fi;
rm -Rf autom4te.cache;
